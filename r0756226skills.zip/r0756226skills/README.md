# 1ITF vervolg skillstaken 
Dit is de basisstructuur voor **Skillstaak 2** en **Skillstaak 3** voor 1ITF van de Thomas More Hogeschool (campus Geel).

<p align="center">
    <img src="https://www.thomasmore.be/themes/wundertheme/logo.svg" alt="Thomas More Kempen" width="300" />
    <meta name="author" content="Juan van Gisbergen">
</p>

